package interfaceLib;

import org.openqa.selenium.WebElement;

public interface ICheckbox {

	public void changeCheckBoxStatus(WebElement element, boolean status) throws Exception;

}
