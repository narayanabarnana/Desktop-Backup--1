package interfaceLib;

import org.openqa.selenium.WebDriver;

public interface ICommonDriver {

public void invokeBrowser(String url) throws Exception;
	
	public void setPageLoadTimeOut(long pageLoadTimeout) throws Exception;
	
	public void setElementDetectionTimeout(long elementDetectionTimeout) throws Exception;
	
	public String getTitle() throws Exception;
	
	public void closeBrowser() throws Exception;
	
	public void closeAllBrowser() throws Exception;
	
	public void naviagteToUrl(String url) throws Exception;
	
	public void naviagteBack(String url) throws Exception;
	
	public void naviagteForward(String url) throws Exception;
	
	public void reloadpage(String url) throws Exception;
	
	public WebDriver getDriver() throws Exception;
}
