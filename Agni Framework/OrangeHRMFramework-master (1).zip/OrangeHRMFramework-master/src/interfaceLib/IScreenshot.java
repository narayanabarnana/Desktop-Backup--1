package interfaceLib;

import org.testng.ITestResult;

public interface IScreenshot {
	
	public void captureAndSaveScreenshotforFailure(String ScreenShotpath, String timeStamp, ITestResult result) throws Exception;
	
	public void captureAndSaveScreenshotAnytime(String ScreenShotpath, String timeStamp) throws Exception;
	

	


}
