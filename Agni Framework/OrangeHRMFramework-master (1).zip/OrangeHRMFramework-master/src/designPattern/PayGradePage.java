package designPattern;

public class PayGradePage {

	public PayGradePage() {
		// TODO Auto-generated constructor stub
	}

}
